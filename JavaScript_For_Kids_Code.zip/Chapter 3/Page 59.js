var 무작위단어 = ["폭발", "동굴", "공주", "펜"];
var 무작위색인 = Math.floor(Math.random() * 4);
무작위단어[무작위색인];
// "동굴"

무작위단어[Math.floor(Math.random()*4)];
// "공주"
