var 고칠문자열 = "hELlo THERE, hOW ARE yOu doINg?";
var 소문자 = 고칠문자열.toLowerCase();
var 첫글자 = 소문자[0];
var 첫글자대문자 = 첫글자.toUpperCase();
var 나머지 = 소문자.slice(1);
첫글자대문자 + 나머지;
// "Hello there, how are you doing?"
