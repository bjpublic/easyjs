var 문자열숫자 = "5";
var 진짜숫자 = 5;
문자열숫자 === 진짜숫자;
// false

문자열숫자 == 진짜숫자;
// true

0 == false;
// true

"false" == false;
// false
