var 고칠문자열 = "hELlo THERE, hOW ARE yOu doINg?";
고칠문자열[0].toUpperCase() + 고칠문자열.slice(1).toLowerCase();
// "Hello there, how are you doing?"
