"Hello there, how are you doing?".toUpperCase();
// "HELLO THERE, HOW ARE YOU DOING?"

"hELlo THERE, hOW ARE yOu doINg?".toLowerCase();
// "hello there, how are you doing?"
