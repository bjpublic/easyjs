var 주말인가요 = false;
var 샤워하기 = true;
var 사과챙기기 = false;
var 오렌지챙기기 = true;
var 나가야하나요 = !주말인가요 && 샤워하기 && (사과챙기기 || 오렌지챙기기);
나가야하나요;
// true
