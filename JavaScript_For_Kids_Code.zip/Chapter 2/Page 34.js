var 키 = 65;
var 키제한 = 60;
키 > 키제한;
// true

var 키 = 60;
var 키제한 = 60;
키 > 키제한;
// false

var 키 = 60;
var 키제한 = 60;
키 >= 키제한;
// true

var 키 = 60;
var 키제한 = 48;
키 < 키제한;
// false

var 키 = 48;
var 키제한 = 48;
키 <= 키제한;
// true
