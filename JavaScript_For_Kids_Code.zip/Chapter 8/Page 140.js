var 점수별메달 = function (점수) {
  if (점수 < 3) {
    return "동메달";
  }
  if (점수 < 7) {
    return "은메달";
  }

  return "금메달";
};
