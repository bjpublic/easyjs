var 처음만든함수 = function () {
  console.log("안녕하세요!");
};

처음만든함수();
// 안녕하세요!
