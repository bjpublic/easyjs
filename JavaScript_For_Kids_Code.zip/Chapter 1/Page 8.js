// 원하는 만큼 고양이를 그려보세요!
var drawCats = function (howManyTimes) {
  for (var i = 0; i < howManyTimes; i++) {
    console.log(i + " =^.^=");
  }
};

drawCats(10); // 10 대신 어떤 숫자를 넣어도 좋습니다..

// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=
// 5 =^.^=
// 6 =^.^=
// 7 =^.^=
// 8 =^.^=
// 9 =^.^=
