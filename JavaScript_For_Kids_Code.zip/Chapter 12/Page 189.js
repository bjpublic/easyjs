var speak = function () {
  console.log(this.sound + "! 내 이름은 " + this.name + "닷!");
};

var cat = {
  sound: "야옹",
  name: "옹디",
  speak: speak
};

cat.speak();
// 야옹! 내 이름은 옹디닷!

var pig = {
  sound: "꿀꿀",
  name: "팔계",
  speak: speak
};

var horse = {
  sound: "히힝",
  name: "프린스",
  speak: speak
};

pig.speak();
// 꿀꿀! 내 이름은 팔계닷!

horse.speak();
// 히힝! 내 이름은 프린스닷!
