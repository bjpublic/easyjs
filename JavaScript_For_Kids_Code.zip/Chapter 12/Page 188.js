var dog = {
  name: "봉구",
  legs: 4,
  isAwesome: true
};

dog.bark = function () {
  console.log("왈왈! 내 이름은 " + this.name + "닷!");
};

dog.bark();
// 왈왈! 내 이름은 봉구닷!
