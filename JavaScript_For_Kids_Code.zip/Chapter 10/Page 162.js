var timeUp = function () {
  alert("시간 끝!");
};

setTimeout(timeUp, 3000);
// 1

setTimeout(timeUp, 5000);
// 2
