var counter = 1;

var printMessage = function () {
  console.log("기록을 시작한 지 " + counter + "초 지났습니다.");
  counter++;
};

var intervalId = setInterval(printMessage, 1000);
// 기록을 시작한 지 1초 지났습니다.
// 기록을 시작한 지 2초 지났습니다.
// 기록을 시작한 지 3초 지났습니다.
// 기록을 시작한 지 4초 지났습니다.
// 기록을 시작한 지 5초 지났습니다.
// 기록을 시작한 지 6초 지났습니다.
clearInterval(intervalId);
