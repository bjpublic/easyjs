var doHomeworkAlarm = function () {
  alert("과제할 시간입니다!");
};

var timeoutId = setTimeout(doHomeworkAlarm, 60000);

clearTimeout(timeoutId);
